let myRec, browserCompatible, pen, direction, displayWord;
var load=1, directionbandit=0, amount=1, shape=0;

function setup() {

    cnv = createCanvas(400, 400);
    background('cyan');
    //Check browser compatibility
    browserCompatible = window.webkitSpeechRecognition ||
        window.mozSpeechRecognition ||
        window.msSpeechRecognition ||
        window.oSpeechRecognition ||
        window.SpeechRecognition;
    //If compatible browser - instantiate 
    if (browserCompatible !== undefined) {
        myRec = new p5.SpeechRec();
        myRec.continuous = true;
        myRec.interimResults = true;
        myRec.onResult = showResult;
        myRec.start();
    }
    displayWord = createDiv();


     ni = {
        x: width / 2,
        y: height / 2,
        size: 6,
        col: color(255, 255, 255, 150),
        show: function () {
            fill(this.col)
            ellipseMode(CENTER)
            ellipse(this.x, this.y, this.size, this.size)
        },
        bounce: function(){
       // if(ni.x < 0){
     // ni.x = 0;
            this.x = this.x < 0 ? 0 : this.x > width ? width : this.x
            
        }
        }
    dest = {
      
     x: ni.x, 
     y: ni.y,
     move : function(){
       if (ni.x < dest.x){
         ni.x++;
       } if (ni.x > dest.x){
        ni.x--;
      } if (ni.y < dest.y){
        ni.y++;
      } if (ni.y > dest.y){
        ni.y--;
      }
      if (dest.x==ni.x && dest.y==ni.y && load==0){
        directionbandit++;
        load=1;
        }

      if (directionbandit<=0){
        dest.x=ni.x;
        dest.y=ni.y;
        directionbandit=1;}
     }
     ,spiral : function(){
      if (directionbandit>=5){
        directionbandit=1;
      }
    if (directionbandit==1 && load==1){
    dest.x=ni.x+(ni.size/3*amount);
    dest.y=ni.y+(ni.size/3*amount);
    load=0;
    amount++;}
  
    if (directionbandit==2 && load==1){
      dest.x=ni.x+(ni.size/3*amount);
      dest.y=ni.y-(ni.size/3*amount);
      load=0;
      amount++;}
     
      if (directionbandit==3 && load==1){
        dest.x=ni.x-(ni.size/3*amount);
        dest.y=ni.y-(ni.size/3*amount);
        load=0;
      amount++;}
    
    if (directionbandit==4 && load==1){
      dest.x=ni.x-(ni.size/3*amount);
      dest.y=ni.y+(ni.size/3*amount);
      load=0;
    amount++;}
     },hus : function(){
if (directionbandit==1 && load==1){
  dest.x=ni.x+50;
  load=0;
} if (directionbandit==2 && load==1){
  dest.y=ni.y-50;
  load=0;
} if (directionbandit==3 && load==1){
  dest.y=ni.y-25;
  dest.x=ni.x-25;
  load=0;
} if (directionbandit==4 && load==1){
 dest.y=ni.y+25;
 dest.x=ni.x-25;
 load=0;
} if (directionbandit==5 && load==1){
  dest.y=ni.y+50;
  load=0;
}},tegn : function(){
if (mouseIsPressed){
load=2;
if (load==2){
  dest.x=mouseX;
  dest.y=mouseY;
  load=0;
}
} 
     }
    
     }}
    
    






function draw() {
    if(direction == "left" || keyIsDown(LEFT_ARROW)) ni.x--;
    if(direction == "right" || keyIsDown(RIGHT_ARROW)) ni.x++;
    if(direction == "up"|| keyIsDown(UP_ARROW)) ni.y--;
    if(direction == "down" || keyIsDown(DOWN_ARROW)) ni.y++;

ni.bounce();
ni.show();
if (shape!=0){
dest.move();}
if (shape==1){
dest.spiral();}
if (shape==2){
  dest.hus();
}
if (shape==3){
  
}
if (shape==4){
dest.tegn();
}
}

function showResult() {
    if (myRec.resultValue == true) {
        word = myRec.resultString.split(' ').pop();
        displayWord.html(word.toLowerCase());
        switch(word) {
            case 'spiral':
            shape=1;
            break;
            case 'hus' :
            shape=2;
            break;
            case 'hjælp':
            alert("former, kommandoer, spil");
            break;

            case 'former':
            alert("Spiral og hus er de eneste :(");
            break;

            case 'kommandoer':
            alert('Musik, tegn');
            break;
            case 'tegn':
            shape=4;
            break;
            
            case 'spil':

            break;

              
            default:
            direction = "stop"
            shape=0;
            directionbandit=0;
            amount=0;
            load=1;
          }
    }
}